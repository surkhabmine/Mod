const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('ਕਿਸੇ ਨੂੰ ਮਿਊਟ ਕਰੋ (Muted Role ਨਾਲ)')
    .addUserOption(opt =>
      opt.setName('user').setDescription('Mute ਕਰਨ ਵਾਲਾ').setRequired(true)
    ),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);
    const muteRole = interaction.guild.roles.cache.find(r => r.name === 'Muted');

    if (!interaction.member.permissions.has('ModerateMembers')) {
      return interaction.reply({ content: 'ਤੁਸੀਂ Mute ਕਰਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਰੱਖਦੇ।', ephemeral: true });
    }

    if (!muteRole) return interaction.reply('Muted ਰੋਲ ਨਹੀਂ ਮਿਲਿਆ।');

    await member.roles.add(muteRole);
    await interaction.reply(`${user.tag} ਨੂੰ ਮਿਊਟ ਕਰ ਦਿੱਤਾ ਗਿਆ 🔇`);
  }
};
