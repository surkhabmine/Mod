const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('ਕਿਸੇ ਮੈਂਬਰ ਨੂੰ ਕਿਕ ਕਰੋ')
    .addUserOption(opt =>
      opt.setName('user').setDescription('ਕੋਨ ਕਿਕ ਕਰਨਾ').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('ਕਾਰਨ').setRequired(false)
    ),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'ਕੋਈ ਕਾਰਨ ਨਹੀਂ ਦਿੱਤਾ';
    const member = interaction.guild.members.cache.get(user.id);

    if (!interaction.member.permissions.has('KickMembers')) {
      return interaction.reply({ content: 'ਤੁਸੀਂ Kick ਦੀ ਪਰਮਿਸ਼ਨ ਨਹੀਂ ਰੱਖਦੇ।', ephemeral: true });
    }

    if (!member) {
      return interaction.reply('ਉਹ ਮੈਂਬਰ ਸਰਵਰ ਵਿੱਚ ਨਹੀਂ।');
    }

    await member.kick(reason);
    await interaction.reply(`${user.tag} ਨੂੰ ਕਿਕ ਕੀਤਾ ਗਿਆ।`);
  }
};
