const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('ਕਿਸੇ ਨੂੰ ਸਰਵਰ ਤੋਂ ਬੈਨ ਕਰੋ')
    .addUserOption(opt =>
      opt.setName('user').setDescription('ਕੋਨ ਬੈਨ ਕਰਨਾ').setRequired(true)
    )
    .addStringOption(opt =>
      opt.setName('reason').setDescription('ਕਾਰਨ').setRequired(false)
    ),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'ਕਾਰਨ ਨਹੀਂ ਦਿੱਤਾ';
    const member = interaction.guild.members.cache.get(user.id);

    if (!interaction.member.permissions.has('BanMembers')) {
      return interaction.reply({ content: 'ਤੁਸੀਂ Ban ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਰੱਖਦੇ।', ephemeral: true });
    }

    if (!member) return interaction.reply('ਉਹ ਮੈਂਬਰ ਮੌਜੂਦ ਨਹੀਂ।');

    await member.ban({ reason });
    await interaction.reply(`${user.tag} ਨੂੰ ਬੈਨ ਕਰ ਦਿੱਤਾ ਗਿਆ। 🚫`);
  }
};
